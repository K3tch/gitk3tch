from django.shortcuts import render

def index(request):
    return render(request,'mainApp/homePage.html')

def contact(request):
    return render(request,'mainApp/basic.html', {'values': ['Phone: +7-905-340-88-17','VK: https://vk.com/ke7ch']})
